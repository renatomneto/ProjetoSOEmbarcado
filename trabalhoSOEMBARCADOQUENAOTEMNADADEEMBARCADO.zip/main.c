#include "kernel.h"

int main(void){
    kernelInit();
    kernelLoop();
}